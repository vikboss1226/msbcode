import express from "express"
// import homeController from "../controllers/homeController"
import chatbotController from "../controllers/chatbotController"

let router = express.Router()   

let initWebRoutes =  (app) => { 
    // router.get("/", homeController.defaultRoute) 
    // get webhook 
    router.get("/webhook",  chatbotController.getWebhook);
    router.post("/webhook",   chatbotController.postWebhook); 
    // initial route test
    
    return app.use("/", router)
}

module.exports = initWebRoutes