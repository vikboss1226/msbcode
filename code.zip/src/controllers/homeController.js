let defaultRoute = (req, res) => {
    return res.send("MSB API Check..!");
};

module.exports = {
    defaultRoute: defaultRoute
};