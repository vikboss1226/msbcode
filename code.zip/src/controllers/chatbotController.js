require("dotenv").config();  

let postWebhook = (req, res) => {
    // Parse the request body from the POST
    let body = req.body;
    console.log("request_body", body) 
};

let getWebhook = (req, res) => {
    let body = req.body;
    console.log("request_body", body) 
};
  

module.exports = {
    postWebhook: postWebhook,
    getWebhook: getWebhook
};