const crypto = require('crypto')

const secret = process.env.APP_SECRET

const fbWebhookAuth = (req, res, next) => {
    const hmac = crypto.createHmac('sha1', secret);
    // hmac.update(req.rawBody, 'utf-8'); //older versions
    hmac.update(req.rawBody, 'utf8');
    if (req.headers['x-hub-signature'] === `sha1=${hmac.digest('hex')}`) {
      return next();
    }
    else {
      console.log("Auth Failed!")
    }
  
  }

  module.exports = {
    fbWebhookAuth: fbWebhookAuth
    };
