require("dotenv").config()
import express from "express"
import bodyParser from "body-parser"
import initWebRoutes from "./routes/web"
 
let app = express() 
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())
app.use(express.static("public")) 
 

app.get("/", (req, res) => {
  res.send("Meta-NodeJS app working fine..!")
})
 
// init web routes
// app.use(middleware.fbWebhookAuth);
initWebRoutes(app)

let port = process.env.PORT || 8080

app.listen(port, () => {
  console.log(`App is running at the port: ${port}`)
})